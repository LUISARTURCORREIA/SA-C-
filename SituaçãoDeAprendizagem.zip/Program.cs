﻿using SituacaoDeAprendizagem.dominioBanco;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SituacaoDeAprendizagem
{
    class Program
    {
        static void Main(string[] args)
        {
            Operacao op = new Operacao();
            while (true)
            {
                string operacoes = "";
                Console.WriteLine($"Seu saldo atual é de {op.saldo}");
            Console.WriteLine("1 - depositar");
            Console.WriteLine("2 - extrato");
            Console.WriteLine("3 - sacar");
            Console.WriteLine("4 - sair");
            Console.WriteLine("Que operação você desejá fazer?");
            operacoes = Console.ReadLine();
            
            if (operacoes.Equals("1"))
            {
                Console.WriteLine("Você escolheu a opção 1 - depositar");
                Console.WriteLine("Informe o valor a ser depositado: ");
                    var valor = Convert.ToDouble(Console.ReadLine());
                    op.deposita(valor);
                    Console.WriteLine("Clique alguma tecla para continuar");
                    Console.ReadLine();
                }
            else if (operacoes.Equals("2"))
            {
                 Console.WriteLine("Você escolheu a opção 2 - extrato");
                 op.extrato();
                    Console.WriteLine("Clique alguma tecla para continuar");
                    Console.ReadLine();
                }
             else if (operacoes.Equals("3"))
             {
              Console.WriteLine("Você escolheu a opção 3 - sacar");
             Console.WriteLine("Informe o valor que desejá sacar:");
                var valor = Convert.ToDouble(Console.ReadLine());
                    op.sacar(valor);
                    Console.WriteLine("Clique alguma tecla para continuar");
                    Console.ReadLine();
                }
            else if (operacoes.Equals("4"))
                {
                    Environment.Exit(1);
                }
                Console.Clear();
            }
        }
    }

}
