﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SituacaoDeAprendizagem.dominioBanco
{
    class Operacao
    {
        public double saldo;
        public List<String> lista = new List<String>();


        public override string ToString()
        {
            StringBuilder operacao = new StringBuilder();

            operacao.AppendLine($"1 - Deposita?");
            operacao.AppendLine($"2 - Sacar?");
            operacao.AppendLine($"3 - Extrato?");
            operacao.AppendLine($"4 - Ver Saldo?");
            operacao.AppendLine($"5 - Sair");

            return operacao.ToString();
        }

        public void deposita(double valor)
        {
            this.saldo += valor;
            this.lista.Add($"Você depositou R${valor} ");
        }
         public void sacar(double valor)
        {
            if(this.saldo < valor)
            {
                Console.WriteLine("Saldo insuficiente");
            }
            else
            {
                this.saldo -= valor;
                this.lista.Add($"Você sacou R${valor} ");
            }
        }

        public void extrato()
        {
            Console.WriteLine($"Seu saldo atual é de R${this.saldo}");
            foreach(String extrato in this.lista)
            {
                Console.WriteLine(extrato);
            }
        }

    }
}
